/**
 * Logo utility for displaying startup banner
 */

import { MCP_SERVER_VERSION } from '../constants.js';

/**
 * ASCII art logo for 1MCP
 */
const LOGO_ART = `
 ██╗███╗   ███╗ ██████╗██████╗
███║████╗ ████║██╔════╝██╔══██╗
╚██║██╔████╔██║██║     ██████╔╝
 ██║██║╚██╔╝██║██║     ██╔═══╝
 ██║██║ ╚═╝ ██║╚██████╗██║
 ╚═╝╚═╝     ╚═╝ ╚═════╝╚═╝     `;

/**
 * Display the startup logo with version and tagline
 */
export function displayLogo(): void {
  console.log('\x1b[36m%s\x1b[0m', LOGO_ART);
  console.log('\x1b[1m%s\x1b[0m', '   All your MCPs in one place');
  console.log('\x1b[2m%s\x1b[0m', `   Version ${MCP_SERVER_VERSION}`);
  console.log('\x1b[2m%s\x1b[0m', '   https://github.com/1mcp-app/agent');
  console.log('\x1b[2m%s\x1b[0m', '   Author: William Xu <xuzp@1mcp.app>');
  console.log('');
}
